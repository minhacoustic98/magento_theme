var config = {
    paths: {            
            'owlcarousel': "Magento_Catalog/js/owl.carousel"
        },   
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};