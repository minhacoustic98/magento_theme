var config = {
    paths: {            
            'slick': "AHT_Fashion/web/js/slick"
        },   
    shim: {
        'slick': {
            deps: ['jquery']
        }
    }
};